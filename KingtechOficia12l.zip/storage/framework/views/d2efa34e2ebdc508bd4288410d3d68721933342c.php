<!doctype html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Documento de Correo</title>
</head>
<body>

<p><strong> Envio de mensajes</strong></p>

<ul>
    <li>
        Nombre: <?php echo e($data['name']); ?>

    </li>
     <li>
        Email: <?php echo e($data['email']); ?>

    </li>
    

    <li>
        Teléfono: <?php echo e($data['phone']); ?>

    </li>
    <li>
        Asunto: <?php echo e($data['subject']); ?>

    </li>
    <li>
        Mensaje: <?php echo e($data['content']); ?>

    </li>



</ul>
<p><b>URL de destino:</b> <a href="<?php echo e($data['url']); ?>"><?php echo e($data['url']); ?></a></p>

</body>
</html>
<?php /**PATH C:\xampp\htdocs\KingtechOficial\resources\views/emails/form-contact/contact.blade.php ENDPATH**/ ?>