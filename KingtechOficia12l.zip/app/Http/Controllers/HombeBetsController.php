<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class HombeBetsController extends Controller
{
    //
}
